<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style type="text/css">
        html, body, #partner, iframe {
            height: 100%;
            width: 100%;
            margin: 0;
            padding: 0;
            border: 0;
            outline: 0;
            font-size: 100%;
            vertical-align: baseline;
            background: transparent;
        }

        body {
            overflow: hidden;
        }
    </style>
    <meta content="NOW" name="expires">
    <meta content="index, follow, all" name="GOOGLEBOT">
    <meta content="index, follow, all" name="robots">
    <!-- Following Meta-Tag fixes scaling-issues on mobile devices -->
    <meta content="width=device-width; initial-scale=1.0; maximum-scale=1.0;
            user-scalable=0;" name="viewport">
</head>
<body>

<div id="partner"></div>
<script type="text/javascript">
    function getParam() {
        var query = window.location.search.substring(1);
        var vars = query.split("&");
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            if (pair[0] == 'domain') {
                return pair[1];
            }
        }
        return  window.location.host;
    }
    ;

    document.write(
            '<script type="text/javascript" language="JavaScript"'
                    + 'src="//sedoparking.com/frmpark/'
                    + getParam() + '/'
                    + 'sedopark'
                    + '/park.js">'
                    + '<\/script>'
    );
</script>
</body>
</html>